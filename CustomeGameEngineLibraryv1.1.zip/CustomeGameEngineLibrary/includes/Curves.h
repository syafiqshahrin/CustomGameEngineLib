#pragma once
#include <cstdlib>
class Curves
{
public:
	static float easeInQuartWithInverseParabola(float t);

};